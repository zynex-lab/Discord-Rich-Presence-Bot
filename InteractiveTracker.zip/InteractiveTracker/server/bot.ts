import Discord from 'discord.js-selfbot-v13';
import { getConfig } from './config';

export async function initializeBot() {
  const client = new Discord.Client({
    checkUpdate: false
  });

  client.on('ready', async () => {
    try {
      const rpc = new Discord.RichPresence(client)
        .setApplicationId('534203414247112723')
        .setType('STREAMING')
        .setURL('https://twitch.tv/discord')
        .setDetails(`zynxer`)
        .setState(`Ад, shadows of evil`)
        .setName(`zynxer`)  
        .setParty({
          max: 5001,
          current: 4690,
          id: client.user?.id || 'default'
        })
        // Try simplified asset format
        .setAssetsLargeImage(`1343960941796266116`)
        .setAssetsLargeText(`.gg/E6ynK4r7WA`)
        .setAssetsSmallImage(`1343960948754612284`)
        .setAssetsSmallText(`decay`)
        .addButton(`rot`, `https://crosshead.tk/`)
        .addButton(`decay`, `https://feds.lol/grim`);

      await client.user?.setActivity(rpc.toJSON());  
      console.log(`${client.user?.tag} is ready!`);
    } catch (err) {
      console.error('Failed to set activity:', err);
    }
  });

  client.on('error', (error) => {
    console.error('Discord client error:', error);
  });

  try {
    const config = getConfig();
    await client.login(config.token);
    return client;
  } catch (err) {
    console.error('Failed to login:', err);
    throw err;
  }
}