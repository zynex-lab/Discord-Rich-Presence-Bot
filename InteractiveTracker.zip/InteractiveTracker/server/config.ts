interface Config {
  token: string;
  port: number;
}

export function getConfig(): Config {
  const token = process.env.TOKEN;
  if (!token) {
    throw new Error('Discord token not found in environment variables');
  }

  return {
    token,
    port: Number(process.env.PORT) || 5000
  };
}
