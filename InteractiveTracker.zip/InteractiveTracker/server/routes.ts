import type { Express } from "express";
import { createServer, type Server } from "http";
import { initializeBot } from './bot';

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Discord bot
  try {
    await initializeBot();
  } catch (err) {
    console.error('Failed to initialize bot:', err);
  }

  // Status endpoint
  app.get('/api/status', (_req, res) => {
    res.json({ status: 'Rich Presence Bot Active' });
  });

  const httpServer = createServer(app);
  return httpServer;
}
