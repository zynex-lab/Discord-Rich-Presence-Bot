import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, CheckCircle } from "lucide-react";

export default function Home() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/status'],
  });

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-6 w-6" />
            Discord Rich Presence Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground">Loading status...</p>
          ) : error ? (
            <p className="text-destructive">Error: Failed to fetch status</p>
          ) : (
            <div className="flex items-center gap-2 text-primary">
              <CheckCircle className="h-5 w-5" />
              <span>{data?.status}</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
